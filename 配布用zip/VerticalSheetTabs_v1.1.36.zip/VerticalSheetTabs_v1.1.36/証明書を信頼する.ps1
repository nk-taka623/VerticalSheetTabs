﻿# 縦並びシートタブの証明書を、このユーザーの「信頼された発行元」と「信頼されたルート証明機関」に登録します。
# 管理者権限は不要です。「信頼されたルート証明機関」への登録では、Windows の確認画面が出ます。「はい」を選んでください。
$cer = Join-Path $PSScriptRoot "VerticalSheetTabs.cer"
Import-Certificate -FilePath $cer -CertStoreLocation Cert:\CurrentUser\TrustedPublisher | Out-Null
Import-Certificate -FilePath $cer -CertStoreLocation Cert:\CurrentUser\Root | Out-Null
Write-Host "証明書を登録しました。続けて setup.exe を実行してください。"